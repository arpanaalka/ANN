Input = importdata('Input.csv');
Input = scaling23(Input);
Target = importdata('Target.csv');

net = fitnet(33,'trainlm');
net.divideFcn='divideblock';
net.divideParam.trainRatio = 0.7;
net.divideParam.valRatio = 0.15;
net.divideParam.testRatio = 0.15;

[net,pr] = train(net,Input',Target');
%Output = net(Sample');